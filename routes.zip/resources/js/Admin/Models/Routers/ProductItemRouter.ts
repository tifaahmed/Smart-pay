
import   RouterRouter    from './Router' ;

export default class ProductItemRouter extends RouterRouter{
    name : string = 'product-item' ;

}