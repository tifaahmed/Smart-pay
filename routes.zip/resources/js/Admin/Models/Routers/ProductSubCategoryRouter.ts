
import   RouterRouter    from './Router' ;

export default class ProductSubCategoryRouter extends RouterRouter{
    name : string = 'product-sub-category' ;

}