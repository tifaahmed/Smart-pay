
import   RouterRouter    from './Router' ;

export default class CouponRouter extends RouterRouter{
    name : string = 'coupon' ;

}