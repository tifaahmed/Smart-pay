
import   RouterRouter    from './Router' ;

export default class ExtraRouter extends RouterRouter{
    name : string = 'extra' ;

}