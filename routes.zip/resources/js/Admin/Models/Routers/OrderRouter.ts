
import   RouterRouter    from './Router' ;

export default class OrderRouter extends RouterRouter{
    name : string = 'order' ;

}