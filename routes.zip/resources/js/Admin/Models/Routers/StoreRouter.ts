
import   RouterRouter    from './Router' ;

export default class StoreRouter extends RouterRouter{
    name : string = 'store' ;

}