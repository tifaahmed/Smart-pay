
import   RouterRouter    from './Router' ;

export default class SubscriptionRouter extends RouterRouter{
    name : string = 'subscription' ;

}