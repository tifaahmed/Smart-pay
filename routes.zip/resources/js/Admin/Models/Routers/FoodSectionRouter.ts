
import   RouterRouter    from './Router' ;

export default class FoodSectionRouter extends RouterRouter{
    name : string = 'food-section' ;

}