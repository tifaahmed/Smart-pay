
import   RouterRouter    from './Router' ;

export default class ExtraCategoryRouter extends RouterRouter{
    name : string = 'extra-category' ;

}