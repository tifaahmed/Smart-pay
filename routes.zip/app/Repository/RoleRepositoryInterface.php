<?php

namespace App\Repository;

interface RoleRepositoryInterface extends EloquentRepositoryInterface{
}
