<?php

namespace App\Repository;

interface FoodSectionRepositoryInterface extends EloquentRepositoryInterface{
}
