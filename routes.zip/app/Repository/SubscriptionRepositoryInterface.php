<?php

namespace App\Repository;

interface SubscriptionRepositoryInterface extends EloquentRepositoryInterface{
}
