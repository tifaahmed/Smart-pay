<?php

namespace App\Repository;

interface CartRepositoryInterface extends EloquentRepositoryInterface{
}
