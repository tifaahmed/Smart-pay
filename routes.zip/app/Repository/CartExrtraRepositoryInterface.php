<?php

namespace App\Repository;

interface CartExrtraRepositoryInterface extends EloquentRepositoryInterface{
}
