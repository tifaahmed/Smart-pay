<?php

namespace App\Repository;

interface CountryRepositoryInterface extends EloquentRepositoryInterface{
}
