<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;

class CarController extends Controller
{
    //
}
