<?php

namespace App\Repository;

interface AddressRepositoryInterface extends EloquentRepositoryInterface{
}
