<?php

namespace App\Repository;

interface ExtraRepositoryInterface extends EloquentRepositoryInterface{
}
