<?php

namespace App\Repository;

interface GovernmentRepositoryInterface extends EloquentRepositoryInterface{
}
