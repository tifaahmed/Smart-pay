<?php

namespace App\Repository;

interface CouponRepositoryInterface extends EloquentRepositoryInterface{
}
