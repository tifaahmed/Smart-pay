<?php

namespace App\Repository;

interface SiteSettingRepositoryInterface extends EloquentRepositoryInterface{
}
