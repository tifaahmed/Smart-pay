<template>
		<router-view></router-view>
</template>

<script>

    export default {
        mounted() {
            console.log( 'all app layout' );
        },
    }
</script>