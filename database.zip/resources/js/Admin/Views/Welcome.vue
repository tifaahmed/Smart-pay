<template>
	<div>
        welcome
	</div>
</template>
<script>

    export default {
        name:'welcome',
        mounted() {
            console.log( 'welcome' )
        },
   }
</script>