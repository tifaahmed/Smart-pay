<template>
        <span v-text="ValueColumn"  /> 

</template>
<script> 
export default {
    data( ) { return {

    } } ,
    props   : {
        ValueColumn :null,
    } ,

} </script>