<template>
    <div>
        <span v-text="ValueColumn"  /> 
    </div>
</template>
<script> 
export default {
    data( ) { return {

    } } ,
    props   : {
        ValueColumn :null,
    } ,

} </script>