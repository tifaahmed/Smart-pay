
import   RouterRouter    from './Router' ;

export default class UserRouter extends RouterRouter{
    name : string = 'user' ;

}