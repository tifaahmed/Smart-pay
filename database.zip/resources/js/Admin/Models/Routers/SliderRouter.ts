
import   RouterRouter    from './Router' ;

export default class SliderRouter extends RouterRouter{
    name : string = 'slider' ;
}