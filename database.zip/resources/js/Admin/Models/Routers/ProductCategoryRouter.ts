
import   RouterRouter    from './Router' ;

export default class ProductCategoryRouter extends RouterRouter{
    name : string = 'product-category' ;

}