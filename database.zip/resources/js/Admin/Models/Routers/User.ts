
import   RouterRouter    from './Router' ;

export default class User extends RouterRouter{
    name : string = 'user' ;

}