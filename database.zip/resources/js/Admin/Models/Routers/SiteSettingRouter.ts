
import   RouterRouter    from './Router' ;

export default class SiteSettingRouter extends RouterRouter{
    name : string = 'site-setting' ;

}