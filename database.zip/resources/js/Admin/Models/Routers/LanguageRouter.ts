
import   RouterRouter    from './Router' ;

export default class LanguageRouter extends RouterRouter{
    name : string = 'language' ;

}