<template>
		<router-view></router-view>
</template>

<script>

    export default {
        mounted() {
            console.log( 'secosssssssssnd layout' );
        },
    }
</script>